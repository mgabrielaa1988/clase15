#include <stdio.h>
#include <stdlib.h>
#define TAM 5

int main()
{
    //int vec[5]; memoria estatica
    int* vec;
    vec = (int*) malloc(TAM*sizeof(int));
    if(vec == NULL){
        printf("\nNo se pudo conseguir memoria\n\n");
        system("pause");
        exit(1);
    }

    for(int i=0;i<TAM;i++){
        printf("Ingrese un numero: ");
        scanf("%d",vec+i);//guarda a partir de esta direccion de memoria
    }

    for(int i=0;i<TAM;i++){//vec+i es la posicion de memoria de cada elemente del vector
        printf("  %d",*(vec+i));//muestro el contenido de cada elemento del vector
    }

    free(vec);

    return 0;
}
